package com.quest.helper;

public interface OnBackPressedListener {
    void onBackPressed();
}
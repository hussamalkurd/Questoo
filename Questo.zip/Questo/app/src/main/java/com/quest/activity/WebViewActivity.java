package com.quest.activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.quest.R;


/**
 * Created by CISS31 on 4/12/2018.
 */

public class WebViewActivity extends AppCompatActivity  {
    private WebView myWebView;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    FragmentManager fragmentManager;
    CardView cardView;
    ImageView btn_back,home_icon;
    String URL;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);

        sharedPreferences=getSharedPreferences("Report",Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
        URL=sharedPreferences.getString("URL","");



        myWebView = (WebView) findViewById(R.id.webView);


        // Make sure we handle clicked links ourselves
        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // we handle the url ourselves if it's a network url (http / https)
                return ! URLUtil.isNetworkUrl(url);
            }
        });

        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.getSettings().setSupportZoom(true);
        myWebView.getSettings().setBuiltInZoomControls(true);
        if (myWebView != null && URL != null) {
            myWebView.loadData(URL,"text/html", null);
        }
    }

}

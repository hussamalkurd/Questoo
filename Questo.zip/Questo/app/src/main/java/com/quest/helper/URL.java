package com.quest.helper;

/**
 * Created by CIS on 1/3/2018.
 */

public class URL {

   public static final String ROOT_URL = "http://merneadan.co.za/QuestoAdmin/process.php?action=";

   public static final String FETCH_CATEGORY= ROOT_URL +"fetch_category";

   public static final String LOGIN=ROOT_URL+"login";

   public static final String REGISTER=ROOT_URL+"register";

   public  static  final String FETCH_QUESTION_CATEGORY=ROOT_URL+"fetch_simple_categorywise";

   public  static final String FETCH_SUBCATEGORY=ROOT_URL+"fetch_subcategory";

   public static final String INSERT_ANSWER=ROOT_URL+"insert_answer";

   public static final String FETCH_QUESTION_ANSWER=ROOT_URL+"fetch_questions";

   public static final String UPDATE_REGISTER=ROOT_URL+"update_register";

   public static final String FETCH_REGISTER=ROOT_URL+"fetch_register";

   public static final String  STATUS_SHOW=ROOT_URL+"status_show";

   public static final String TRANSACTION_HISTORY=ROOT_URL+"transaction_history";

   public static final String GET_WINNING_PRICE=ROOT_URL+"get_winning_price";

   public static final String moneydeduct=ROOT_URL+"wallet_moneydeduct";

   public static final String moneysend=ROOT_URL+"wallet_moneysend";

   public static final String checkuser=ROOT_URL+"wallet_checkuser";

   public static final String FETCHANSWERCOUNTER=ROOT_URL+"count_right_wrong_answer";

   public static final String DELETEANSWER=ROOT_URL+"delete_userwise_subcategory_answer";


}

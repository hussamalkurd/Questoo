package com.quest.helper;

public interface PlacementId {
    //   long YOUR_PLACEMENT_ID = 1515867185282L;
    //  long YOUR_PLACEMENT_ID = 1515800602351L;
    long YOUR_PLACEMENT_ID = 1516162687671L;
}